# Going live with real money: checklist

Do these in order. Don't skip a step because an earlier one passed.

## 1. Paper results first (DRY_RUN=true)
- Run the bot in paper mode for **at least 3 trading days** with Decu active.
- Dashboard (`/api/status` → `paper`) shows profit per sell timing:
  `buy+4s`, `buy+5s` (sell 4–5 s after your buy) and `his-sell+0s`, `his-sell+10s` (sell after he does).
- **Only go live if the timing you will actually use is positive over 100+ trades.**
  Hand-selling realistically means `his-sell+10s` or slower. `buy+4s`/`buy+5s` needs automatic selling.
- What the Solscan paper tests found on 2026-10-06/07 (sell 4–5 s after buy): 61 trades, 16 wins, −0.133 SOL.
  Selling 8–15 s after he sold: 62 trades, 11 wins, −0.263 SOL. Neither was profitable.

## 2. Wallet
- Use a **separate trading wallet** that holds only what you can lose. Never your main wallet.
- Fund it with at least: copies you want per day × ~0.125 SOL + 0.02 SOL reserve.
  (0.1 buy + 20% slippage room + 0.001 tip + 0.0005 priority fee + fees.)
- The key goes ONLY in `.env` on the computer/server or Render's secret settings. Never in chat.

## 3. Settings (`.env` or Render Environment)
| Setting | Value | Why |
|---|---|---|
| `DRY_RUN` | `false` | real trades |
| `PRIVATE_KEY` | your trading wallet key | signing happens locally |
| `ENGINE_STATE_FILE` | `engine-live.json` (Render: `/var/data/engine-live.json`) | the bot refuses to mix paper and live state |
| `DASHBOARD_TOKEN` | 24+ random characters | required for live |
| `HELIUS_API_KEY` | your key | fast detection + Helius Sender |
| `SOLSCAN_API_KEY` | your key | second watcher, gap alerts, coin names |
| `PUMPPORTAL_API_KEY` | your key (secret) | PumpPortal's live feed of Decu's trades, a second way to see them; keep at least 0.02 SOL in the key's linked PumpPortal wallet (0.01 SOL per 10,000 of his trades) |
| `NTFY_TOPIC` | your topic | buy / SOLD / failure alerts |
| `SIZING_MODE` / `BUY_SOL` / `DAILY_CAP_SOL` | `fixed` / `0.1` / `0` | `0` = no daily spending cap: only the wallet balance limits buys |
| `AUTO_SELL` | `false` | you sell by hand from the SOLD alert |
| `SLIPPAGE_PCT` | `20` | 10% failed often on his coins |
| `MAX_PAY_ABOVE_DECU_PCT` | `15` (default) | entry-premium filter (price vs price), fail-closed: skip buys over 15% above Decu's price, or when a price is missing |
| `FILTER_REPORT_PCTS` | `10,25` | alerts also show what a 10% and a 25% limit would have done (report only) |
| `FEE_MODE` | `max` (default) | market fees on every buy and sell, capped by `PRIORITY_FEE_MAX_SOL` `0.001` + `TIP_MAX_SOL` `0.002` (at most 0.003 SOL per side). `fixed` = `PRIORITY_FEE_SOL` + `TIP_SOL` |
| `LOCAL_SELL` / `CLOSE_TOKEN_ACCOUNT` | `true` / `true` | the bot builds its sells itself (PumpPortal as fallback) and closes the token account when it sells everything (rent back) |
| `SOLSCAN_MAX_PER_DAY` | `2500` | hard daily Solscan request budget (100 CU each) |
| `PUSH_STREAM` | `true` | blocks, confirmations and prices pushed over the websocket (faster stop-loss and confirmations) |
| `NTFY_TOKEN` | optional | ntfy access token: lifts the free daily alert limit |
| `SENDER_URL` | Render (Oregon): `http://slc-sender.helius-rpc.com/fast` | the regional Helius Sender nearest the server (the API key is never sent over http) |
| `MAX_OPEN_POSITIONS` | `2` | at most 2 coins at once |
| `DAILY_CAP_USD` | `600` | at most $600 of buys a day |
| `SELL_SLIPPAGE_PCT` | `35` | sells fill even on a falling coin |
| `DAILY_LOSS_LIMIT_SOL` | `0` (off) | optional: stop new buys for the day after losing this much |

## 3b. Data health: `node copybot.mjs diagnose`
Read-only. Compares Helius and Solscan: both answer, how far Solscan's index trails, SOL price from
Solscan / Helius / Jupiter / DexScreener, every Solscan swap present in Helius history, and the
bot's own trade parser vs Solscan's decoding of his last 15 swaps. Fix every WARN before going live.
It also profiles him: coins per hour, wins, and the median seconds between his first buy over
`MIN_LEADER_BUY_USD` and his first sell (your whole window). Report saved to `diagnose-<date>.json`.

## 4. Preflight: must print "READY FOR LIVE"
Easiest: double-click `go-live-mac.command` / `go-live-windows.bat` (or `node copybot.mjs setup --live`).
It asks for the wallet key without showing it, sets DRY_RUN=false (no daily spending cap) and the
live state file, then runs the check below. `setup --paper` switches back.

```
node copybot.mjs check
```
With the key set, this builds a **real 0.1 SOL buy**, adds the tip, signs it and runs the full safety
simulation. It **does not send it**. Every line must say OK. It checks:
RPC, his wallet history, live SOL price, websocket subscription, wallet balance vs one copy,
Helius (not public RPC), phone alert, dashboard token, live state file, the full buy path, Helius Sender.

## 5. First live day: smallest possible
- There is no daily spending cap: the SOL you put in the wallet is the limit. Fund it with only what you are willing to lose. Watch every alert and check each transaction on Solscan.
- Raise to 1 SOL only after the real fills match what paper mode predicted.

## What protects your money
- Every live transaction is checked before sending: the only SOL that can leave is the buy itself
  (max BUY_SOL + slippage), the tip, and fees. Transfers to any other address, token transfers and
  approvals are refused. One pump.fun trade per transaction, then a full simulation must match.
- Per-coin once rule, wallet reserve (optional DAILY_CAP_SOL), pause button (stops new buys) on the dashboard.
- Signed transactions are saved before sending; after a crash the bot re-checks them instead of buying twice.
