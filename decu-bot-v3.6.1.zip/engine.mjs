import fs from 'node:fs';

export function sizeBuy(c, signal, balance, reserved, spent) {
  const spendable = Math.max(0, balance - reserved - c.reserve - c.feeBudget);
  if (c.sizing === 'proportional' && !(signal.leaderBalanceSol > 0)) throw new Error('leader pre-trade SOL balance unavailable');
  const desired = c.sizing === 'proportional' ? spendable * Math.min(1, signal.sol / signal.leaderBalanceSol) * c.multiplier : c.buySol;
  const sol = Math.floor(Math.max(0, Math.min(desired, c.maxBuy, spendable / (1 + c.slippage / 100), c.dailyCap - spent)) * 1e9) / 1e9;
  if (sol < c.minBuy) throw new Error(c.dailyCap - spent < c.minBuy ? `daily spending cap reached (${spent.toFixed(2)} of ${c.dailyCap.toFixed(2)} SOL today${c.dailyCapUsd ? `, $${c.dailyCapUsd}` : ''})` : 'trade too small or wallet balance too low');
  return sol;
}

export function fractionRaw(held, sold, before) {
  held = BigInt(held); sold = BigInt(sold); before = BigInt(before);
  if (before <= 0n || sold <= 0n) throw new Error('leader pre-sell balance unavailable');
  return held * (sold > before ? before : sold) / before;
}

export class Engine {
  constructor({file, config, adapter, log = () => {}}) {
    this.file = file; this.c = config; this.a = adapter; this.log = log;
    this.tasks = new Map(); this.serial = Promise.resolve(); this.reconciling = false;
    this.d = {version: 2, mode: config.mode, wallet:config.wallet || null, paused: false, autoCopy: config.autoCopy ?? config.autoSell ?? false, daily: {}, seen: {}, positions: {}, jobs: {}, queues: {}, events: [], paperBalance: config.paperBalance};
    if (fs.existsSync(file)) {
      this.d = JSON.parse(fs.readFileSync(file, 'utf8'));
      if (this.d.version !== 2 || this.d.mode !== config.mode) throw new Error('state version/mode mismatch; use separate state files');
      if (config.mode==='live' && this.d.wallet!==config.wallet) throw new Error('state belongs to a different trading wallet');
      // State saved before the auto-copy switch existed: use the configured default, not "off".
      if (this.d.autoCopy === undefined) this.d.autoCopy = config.autoCopy ?? false;
      this.prune();
    }
  }
  day() { return (this.dayFmt ||= new Intl.DateTimeFormat('en-CA', {timeZone: this.c.timezone, year:'numeric', month:'2-digit', day:'2-digit'})).format(new Date()); }
  save() {
    if (this.saveTimer) { clearImmediate(this.saveTimer); this.saveTimer = null; }
    const tmp = this.file + '.tmp'; fs.writeFileSync(tmp, JSON.stringify(this.d), {mode:0o600}); fs.renameSync(tmp, this.file);
  }
  // BUY PATH SPEED: nothing irreversible happens before the signed transaction is saved (the one write
  // that must come before a send), so the steps before it save and log a moment later, off the buy path,
  // while the bot waits on the network. A real save before then includes everything anyway.
  saveSoon() { this.saveTimer ||= setImmediate(() => { this.saveTimer = null; try { this.save(); } catch (e) { console.error('state save failed (retried on the next save):', e.message); } }); }
  event(type, fields = {}, {soon = false} = {}) {
    const e = {time:new Date().toISOString(), type, ...fields};
    this.d.events.push(e); if (this.d.events.length > 300) this.d.events = this.d.events.slice(-250);
    if (soon) { this.saveSoon(); setImmediate(() => this.emit(e)); } else { this.save(); this.emit(e); }
  }
  emit(e) { try { this.log(e); } catch (error) { console.error('event log unavailable:', error.message); } }
  lock(fn) { const p = this.serial.then(fn); this.serial = p.catch(() => {}); return p; }
  /** Coins held plus buys being built/sent or queued. */
  openCount() { const m = new Set(Object.entries(this.d.positions).filter(([,p]) => BigInt(p.raw || '0') > 0n).map(([k]) => k)); for (const j of Object.values(this.d.jobs)) if (j.side === 'buy') m.add(j.mint); for (const [k,q] of Object.entries(this.d.queues)) if (q?.some(x => x.side === 'buy')) m.add(k); return m.size; }
  reserved() { return Object.values(this.d.jobs).filter(j => j.side === 'buy').reduce((s,j) => s+j.reserveSol,0); }
  async ingest(s) {
    return this.lock(async () => {
      const key = `${s.sig}:${s.side}:${s.mint}`;
      if (this.d.seen[key]) return;
      this.event('detected', {side:s.side, mint:s.mint, leaderSignature:s.sig}, {soon:true});
      let reason;
      if (s.side === 'buy') {
        // Buying happens in both trading styles; only Pause stops it.
        if (this.d.paused) reason = 'new buys paused';
        // DAILY_LOSS_LIMIT_SOL (0 = off): closed trades lost this much today -> no new buys until tomorrow.
        else if (this.c.dailyLossLimit > 0 && (this.d.dailyPnl?.[this.day()] || 0) <= -this.c.dailyLossLimit) reason = 'daily loss limit reached';
        else if (Date.now()/1000 - s.time > this.c.maxAge) reason = 'stale buy signal';
        else if (!s.pump && this.c.pumpOnly) reason = 'not a pump trade';
        else if (s.usd < this.c.minLeaderUsd) reason = 'leader buy below minimum';
        else if (this.c.oneBuy && (this.d.positions[s.mint] || this.d.jobs[s.mint] || this.d.queues[s.mint]?.some(x=>x.side==='buy'))) reason = 'already copied mint';
        // MAX_OPEN_POSITIONS (2): coins held + buys in flight. A Decu buy over the limit is skipped (and still studied).
        else if (this.c.maxPositions > 0 && this.openCount() >= this.c.maxPositions) reason = `max open positions reached (${this.c.maxPositions} coins)`;
        // Circuit breakers from the runtime (stale market data, several failed buys in a row).
        else if (this.c.gate && (reason = this.c.gate())) { /* reason set */ }
      } else if (!this.d.autoCopy && !s.force) {
        // Manual-sell style (auto copy OFF): never sell; alert the moment he sells a coin the bot holds,
        // so the user can sell by hand in Phantom.
        if (this.d.positions[s.mint] || this.d.jobs[s.mint] || this.d.queues[s.mint]?.length) {
          this.d.seen[key] = Date.now();
          this.event('leader-sold', {mint:s.mint, leaderSignature:s.sig, soldRaw:s.soldRaw, beforeRaw:s.beforeRaw});
        }
        return;
      }
      else if (!this.d.positions[s.mint] && !this.d.jobs[s.mint] && !this.d.queues[s.mint]?.length) reason = 'no bot position';
      else if (this.c.maxSellAge > 0 && Date.now()/1000 - s.time > this.c.maxSellAge) reason = 'stale sell signal; inspect position';
      this.d.seen[key] = Date.now();
      if (reason) { this.event('skip', {mint:s.mint, side:s.side, reason}, {soon:true}); return; }
      (this.d.queues[s.mint] ||= []).push({...s, key}); this.saveSoon();
      this.schedule(s.mint);
    });
  }
  schedule(mint) {
    if (this.tasks.has(mint) || this.d.jobs[mint]) return;
    // Start outside the global lock; confirmations never hold that lock.
    const p = Promise.resolve().then(() => this.drain(mint)).catch(e => this.event('error',{mint,message:e.message})).finally(() => this.tasks.delete(mint));
    this.tasks.set(mint,p);
  }
  async drain(mint) {
    while (this.d.queues[mint]?.length && !this.d.jobs[mint]) {
      let job;
      await this.lock(async () => {
        const s = this.d.queues[mint][0];
        try {
          job = {...s, id:s.key, day:this.day(), phase:'building'};
          if (s.side === 'buy') {
            if (this.d.paused) throw new Error('new buys paused');
            const balance = this.c.mode === 'live' ? await this.a.balance() : this.c.paperUnlimited ? Math.max(this.d.paperBalance, 1e6) : this.d.paperBalance;
            // DAILY_CAP_USD (600): converted to SOL with Decu's own trade (his $ / his SOL), no extra API call.
            const capSol = this.c.dailyCapUsd > 0 && s.usd > 0 && s.sol > 0 ? Math.min(this.c.dailyCap, this.c.dailyCapUsd / (s.usd / s.sol)) : this.c.dailyCap;
            job.sol = sizeBuy({...this.c, dailyCap: capSol},s,balance,this.c.paperUnlimited ? 0 : this.reserved(),this.d.daily[job.day] || 0);
            job.reserveSol = job.sol * (1 + this.c.slippage/100) + this.c.feeBudget;
            this.d.daily[job.day] = (this.d.daily[job.day] || 0) + job.sol;
          } else {
            const p = this.d.positions[mint];
            if (!p || BigInt(p.raw) === 0n) throw new Error('no filled bot position');
            let available = BigInt(p.raw), onChain = BigInt(p.raw);
            if (this.c.mode === 'live') { onChain = BigInt(await this.a.tokens(mint)); if (onChain < available) available = onChain; }
            job.raw = fractionRaw(available,s.soldRaw,s.beforeRaw).toString();
            // what the wallet holds on-chain: a sell of exactly this much may also close the token account
            job.chainRaw = onChain.toString();
            if (BigInt(job.raw) === 0n) throw new Error('sell rounds to zero tokens');
          }
          this.d.jobs[mint] = job; this.d.queues[mint].shift(); this.event('building',{mint,side:job.side,sol:job.sol,raw:job.raw},{soon:true});
        } catch (e) { this.d.queues[mint].shift(); job = null; this.event('skip',{mint,reason:e.message}); }
      });
      if (!job) continue;
      try {
        const built = await this.a.build(job);
        Object.assign(job,built,{phase:'submitted'});
        this.event('submitted',{mint,side:job.side,signature:job.signature},{soon:true});
        // Persist the signed transaction BEFORE any broadcast (one write; it also carries every step above).
        // Recovery can resend identical bytes.
        this.save();
        const result = await this.a.send(job);
        await this.finish(job,result);
      } catch (e) {
        if (job.phase === 'building') await this.finish(job,{status:'failed',error:e.message});
        else { job.phase = 'unresolved'; this.event('unresolved',{mint,signature:job.signature,message:e.message}); }
      }
    }
  }
  async finish(job,result) {
    if (result.status === 'unresolved') { job.phase='unresolved'; this.event('unresolved',{mint:job.mint,signature:job.signature,message:result.error}); return; }
    await this.lock(async () => {
      const p = this.d.positions[job.mint] ||= {raw:'0',costSol:0,realizedSol:0};
      if (result.status === 'confirmed') {
        const delta = BigInt(result.rawDelta);
        const nextRaw=BigInt(p.raw)+delta;
        if (nextRaw < 0n) throw new Error('negative position: reconciliation required');
        p.raw = nextRaw.toString();
        if (job.side === 'buy') { p.costSol += -result.solDelta; p.boughtAt ||= Date.now(); }
        else { p.realizedSol += result.solDelta; if (nextRaw === 0n) { const d = this.day(); (this.d.dailyPnl ||= {})[d] = (this.d.dailyPnl[d] || 0) + p.realizedSol - p.costSol; } }
        if (this.c.mode !== 'live') this.d.paperBalance += result.solDelta;
        delete this.d.jobs[job.mint];
        this.event('confirmed',{mint:job.mint,side:job.side,signature:job.signature,rawDelta:result.rawDelta,solDelta:result.solDelta});
      } else {
        if (job.side === 'buy') this.d.daily[job.day] = Math.max(0,(this.d.daily[job.day] || 0)-job.sol);
        if (BigInt(p.raw) === 0n && !p.costSol) delete this.d.positions[job.mint];
        delete this.d.jobs[job.mint];
        this.event('failed',{mint:job.mint,side:job.side,signature:job.signature,message:result.error});
      }
      delete this.d.jobs[job.mint]; this.save();
    });
  }
  async recover() {
    if (this.reconciling) return; this.reconciling = true;
    try {
      for (const job of Object.values(this.d.jobs)) {
        if (this.tasks.has(job.mint)) continue;
        if (job.phase === 'building') { await this.finish(job,{status:'failed',error:'restart before signed transaction was persisted; no send occurred'}); continue; }
        try { await this.finish(job,await this.a.reconcile(job)); }
        catch(e) { this.event('error',{mint:job.mint,message:e.message}); }
      }
      for (const mint of Object.keys(this.d.queues)) this.schedule(mint);
    } finally { this.reconciling = false; }
  }
  // Forget duplicate-protection keys older than 2 days. Older signals are refused as stale anyway,
  // and without this the state file (rewritten on every event) grows by ~1,500 keys a day.
  prune(maxAgeMs = 2*86400e3) {
    const cut = Date.now()-maxAgeMs; let n = 0;
    for (const [k,t] of Object.entries(this.d.seen)) if (!(t >= cut)) { delete this.d.seen[k]; n++; }
    return n;
  }
  pause(value) { this.d.paused=value; this.event(value ? 'paused' : 'resumed'); }
  // Two toggles on the dashboard. 'auto' = auto buy + auto sell, 'manual' = auto buy + manual sell,
  // 'off' = no new buys (positions already held keep the selling style they had).
  style(value) {
    if (value === 'off') { this.d.paused = true; this.event('style', {style:'off', message:'both toggles off: no new buys'}); return; }
    this.d.autoCopy = value === 'auto'; this.d.paused = false;
    this.event('style', {style:value, message:value === 'auto' ? 'auto buy + auto sell' : 'auto buy + manual sell'});
  }
  autoCopy(value) { this.d.autoCopy=!!value; this.event(value ? 'auto-copy-on' : 'auto-copy-off'); }
  // Phone alerts on/off. Saved in the state file, so it survives restarts.
  mute(value) { this.d.alertsOff=value; this.event(value ? 'alerts-off' : 'alerts-on'); }
  snapshot() {
    const jobs = Object.values(this.d.jobs).map(({mint,side,phase,signature,sol,raw}) => ({mint,side,phase,signature,sol,raw}));
    return {mode:this.c.mode,autoSell:this.c.autoSell,autoCopy:!!this.d.autoCopy,paused:this.d.paused,alertsOff:!!this.d.alertsOff,balance:this.c.mode === 'live' ? null : this.d.paperBalance,spent:this.d.daily[this.day()] || 0,cap:Number.isFinite(this.c.dailyCap)?this.c.dailyCap:null,pnlToday:this.d.dailyPnl?.[this.day()] || 0,lossLimit:this.c.dailyLossLimit || 0,open:this.openCount(),maxPositions:this.c.maxPositions || 0,capUsd:this.c.dailyCapUsd || 0,gate:this.c.gate?.() || null,reserved:this.reserved(),positions:this.d.positions,jobs,events:this.d.events.slice(-100)};
  }
  async idle() { await this.serial; while(this.tasks.size) await Promise.all([...this.tasks.values()]); }
}
